# The purpose of database:
Sparkify want to move their processes and data onto the cloud, and this database will store user base and song database of them and continue finding insights into what songs their users are listening to.

# This project does:
- Design database schema
- Create staging tables and analytics tables
- Load data from S3 into staging tables
- Load data from staging tables into analytics tables